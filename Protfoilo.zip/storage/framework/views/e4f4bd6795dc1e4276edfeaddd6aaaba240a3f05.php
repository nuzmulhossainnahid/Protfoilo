

<?php $__env->startSection('title'); ?>Home <?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

    <div class="container-scroller">
        <?php echo $__env->make('admin.home.navbarTop', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('admin.home.navbarDown', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="container-fluid page-body-wrapper">
            <!-- partial:partials/_settings-panel.html -->
        <?php echo $__env->make('admin.home.themSeteing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- partial -->
        <?php echo $__env->make('admin.home.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- partial -->
            <div class="main-panel">
                <div class="content-wrapper">
                    <div class="col-12 grid-margin stretch-card">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Edit Skill Section</h4>

                                <form class="forms-sample" action="<?php echo e(url('editSkillFrom',$data->id)); ?>" method="post" enctype="multipart/form-data" >
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label for="exampleInputName1">Skill Name</label>
                                        <input type="text" name="skillName" class="form-control" id="exampleInputName1" value="<?php echo e($data->skillName); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputName1">Percentage</label>
                                        <input type="number" name="percentage" class="form-control" id="exampleInputName1" value="<?php echo e($data->percentage); ?>">
                                    </div>
                                    <input type="submit"   class="btn btn-success mr-2" style="background-color: green">
                                    <button class="btn btn-light" style="background-color: red">Cancel</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- content-wrapper ends -->
            <?php echo $__env->make('admin.home.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- partial -->
            </div>
            <!-- main-panel ends -->
        </div>
        <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.include.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\DHAKA INTERNATIONAL UNIVERSITY (DEPARTMENT OF CSE 51 BATCH\FREASH_PROJECT\Protfoilo\resources\views/admin/about/editSkill.blade.php ENDPATH**/ ?>