<!-- Portfolio Start -->
<div class="portfolio" id="portfolio">
    <div class="content-inner">
        <div class="content-header">
            <h2>Portfolio</h2>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <ul id="portfolio-flters">
                    <li data-filter="*" class="filter-active">All</li>
                    <li data-filter=".web-des">Design</li>
                    <li data-filter=".web-dev">Development</li>
                    <li data-filter=".art-Int">Artificial Intelligence</li>
                </ul>
            </div>
        </div>
        <div class="row portfolio-container">

            <?php $__currentLoopData = $portfolio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $portfolio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6 portfolio-item <?php echo e($portfolio->projectCategory); ?>">

                <div class="portfolio-wrap">
                    <figure>
                        <img src="PortfolioImage/<?php echo e($portfolio->image); ?>" class="img-fluid" alt="">
                        <a href="PortfolioImage/<?php echo e($portfolio->image); ?>" data-lightbox="portfolio" data-title="Project Name" class="link-preview" title="Preview"><i class="fa fa-eye"></i></a>
                        <a href="<?php echo e($portfolio->projectLink); ?>" class="link-details" title="More Details"><i class="fa fa-link"></i></a>
                        <a class="portfolio-title" href="#">Project Name <span><?php echo e($portfolio->projectName); ?></span></a>
                    </figure>
                </div>

            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
</div>
<!-- Portfolio Start --><?php /**PATH G:\DHAKA INTERNATIONAL UNIVERSITY (DEPARTMENT OF CSE 51 BATCH\FREASH_PROJECT\Protfoilo\resources\views/user/home/portfoilio.blade.php ENDPATH**/ ?>