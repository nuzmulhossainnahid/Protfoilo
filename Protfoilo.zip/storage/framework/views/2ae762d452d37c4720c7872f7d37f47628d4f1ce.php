<!-- About Start -->
<div class="about" id="about">
    <div class="content-inner">
        <div class="content-header">
            <h2>About Me</h2>
        </div>
        <div class="row align-items-center">
            <div class="col-md-6 col-lg-5">
                <img src="AboutImage/<?php echo e($about->aboutImage); ?>" alt="Image">
            </div>
            <div class="col-md-6 col-lg-7">
                <p>
                   <?php echo e($about->discription); ?>

                </p>
                <a class="btn" href="https://mail.google.com/mail/?view=cm&fs=1&to=<?php echo e($contact->email); ?>">Hire Me</a>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $skill; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6">
                <div class="skills">
                    <div class="skill-name">
                        <p><?php echo e($skill->skillName); ?></p><p><?php echo e($skill->percentage); ?>%</p>
                    </div>
                    <div class="progress">
                        <div class="progress-bar" role="progressbar" aria-valuenow="<?php echo e($skill->percentage); ?>" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>

                </div>
            </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
</div>
<!-- About End --><?php /**PATH G:\DHAKA INTERNATIONAL UNIVERSITY (DEPARTMENT OF CSE 51 BATCH\FREASH_PROJECT\Protfoilo\resources\views/user/home/about.blade.php ENDPATH**/ ?>