<!-- Footer Start -->
<div class="footer">
    <div class="content-inner">
        <div class="row align-items-center">
            <div class="col-md-6">
                <p>&copy; Copyright <a href="">PortfolioPoint</a>. All Rights Reserved</p>
            </div>
            <div class="col-md-6">
                <p>Powered by <a href="https://www.facebook.com/profile.php?id=100011524358252">Md. Nuzmul Hossain Nahid</a></p>
            </div>
        </div>
    </div>
</div>
<!-- Footer Start --><?php /**PATH G:\DHAKA INTERNATIONAL UNIVERSITY (DEPARTMENT OF CSE 51 BATCH\FREASH_PROJECT\Protfoilo\resources\views/user/home/footer.blade.php ENDPATH**/ ?>