<!-- Experience Start -->
<div class="experience" id="experience">
    <div class="content-inner">
        <div class="content-header">
            <h2>Experience</h2>
        </div>
        <div class="row align-items-center">
            <?php $__currentLoopData = $experience; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6">
                <div class="exp-col">
                    <span><?php echo e($experience->startingDate); ?> <i>to</i> <?php echo e($experience->endingDate); ?></span>
                    <h3><?php echo e($experience->degreeName); ?></h3>
                    <h4><?php echo e($experience->address); ?></h4>
                    <h5><?php echo e($experience->post); ?></h5>
                    <p><?php echo e($experience->discription); ?></p>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<!-- Experience Start --><?php /**PATH G:\DHAKA INTERNATIONAL UNIVERSITY (DEPARTMENT OF CSE 51 BATCH\FREASH_PROJECT\Protfoilo\resources\views/user/home/experience.blade.php ENDPATH**/ ?>