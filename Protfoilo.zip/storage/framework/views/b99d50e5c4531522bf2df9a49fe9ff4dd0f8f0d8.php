<!-- Education Start -->
<div class="education" id="education">
    <div class="content-inner">
        <div class="content-header">
            <h2>Education</h2>
        </div>
        <div class="row align-items-center">
            <?php $__currentLoopData = $education; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6">
                <div class="edu-col">
                    <span><?php echo e($education->startingDate); ?> <i>to</i> <?php echo e($education->endingDate); ?></span>
                    <h3><?php echo e($education->degreeName); ?></h3>
                    <p><?php echo e($education->discription); ?></p>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<!-- Education Start --><?php /**PATH G:\DHAKA INTERNATIONAL UNIVERSITY (DEPARTMENT OF CSE 51 BATCH\FREASH_PROJECT\Protfoilo\resources\views/user/home/education.blade.php ENDPATH**/ ?>