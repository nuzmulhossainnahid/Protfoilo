<!-- Service Start -->
<div class="service" id="service">
    <div class="content-inner">
        <div class="content-header">
            <h2>Service</h2>
        </div>
        <div class="row align-items-center">
            <?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6">
                <div class="srv-col">

                    <i class="fa fa-server"></i>
                    <h3><?php echo e($service->nameOfServices); ?></h3>
                    <p><?php echo e($service->discription); ?></p>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<!-- Service Start --><?php /**PATH G:\DHAKA INTERNATIONAL UNIVERSITY (DEPARTMENT OF CSE 51 BATCH\FREASH_PROJECT\Protfoilo\resources\views/user/home/service.blade.php ENDPATH**/ ?>