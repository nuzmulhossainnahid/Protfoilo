

<?php $__env->startSection('title'); ?>Home <?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

    <div class="container-scroller">
        <?php echo $__env->make('admin.home.navbarTop', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('admin.home.navbarDown', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="container-fluid page-body-wrapper">
            <!-- partial:partials/_settings-panel.html -->
        <?php echo $__env->make('admin.home.themSeteing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- partial -->
        <?php echo $__env->make('admin.home.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- partial -->
            <div class="main-panel">
                <div class="content-wrapper">
                    <div class="col-lg-12 grid-margin stretch-card">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Slider Image</h4>

                                <div class="table-responsive">
                                    <table class="table table-striped">
                                        <thead>
                                        <tr>
                                            <th>
                                                Slider Image
                                            </th>
                                            <th>
                                                Delete
                                            </th>
                                            <th>
                                                Change
                                            </th>

                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <td class="py-1">
                                                <img src="SliderImage/<?php echo e($data->sliderImage); ?>" style="width: 200px; height: 200px" alt="image"/>
                                            </td>
                                            <td>
                                                <a href="<?php echo e(url('deleteSlider',$data->id)); ?>"><button class="btn btn-light" style="background-color: red; color: white">Delete</button></a>

                                            </td>
                                            <td>
                                                <a href="<?php echo e(url('changeSlider',$data->id)); ?>"><button class="btn btn-light" style="background-color: #0000cc; color: white">Change</button></a>

                                            </td>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </tr>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- content-wrapper ends -->
            <?php echo $__env->make('admin.home.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- partial -->
            </div>
            <!-- main-panel ends -->
        </div>
        <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.include.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\DHAKA INTERNATIONAL UNIVERSITY (DEPARTMENT OF CSE 51 BATCH\FREASH_PROJECT\Protfoilo\resources\views/admin/SliderImage/adminSliderImage.blade.php ENDPATH**/ ?>