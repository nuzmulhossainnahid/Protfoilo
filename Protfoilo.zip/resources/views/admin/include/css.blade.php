<link rel="stylesheet" href="admin/vendors/typicons/typicons.css">
<link rel="stylesheet" href="admin/vendors/css/vendor.bundle.base.css">
<!-- endinject -->
<!-- plugin css for this page -->
<!-- End plugin css for this page -->
<!-- inject:css -->
<link rel="stylesheet" href="admin/css/vertical-layout-light/style.css">
<!-- endinject -->
<link rel="shortcut icon" href="admin/images/favicon.png" />