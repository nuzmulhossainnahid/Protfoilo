<!-- partial:partials/_footer.html -->
<footer class="footer">
    <div class="card">
        <div class="card-body">
            <div class="d-sm-flex justify-content-center justify-content-sm-between">
                <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © 2022 <a href="" class="text-muted" target="_blank">PortfolioPoint</a>. All rights reserved.</span>
                <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center text-muted">Developed by <a href="https://www.facebook.com/profile.php?id=100011524358252" class="text-muted" target="_blank">Md. Nuzmul Hossain Nahid</a></span>
            </div>
        </div>
    </div>
</footer>