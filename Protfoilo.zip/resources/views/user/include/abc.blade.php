@extends('user.include.main')
@section('title')
    Home Page
@endsection

@section('content')
    @include('user.home.topbar')


    @include('user.home.navbar')







    @include('user.home.footer')
@endsection